COMMERCIAL PPT ENGINE / FIRST-MILESTONE COMPILER SAMPLES

三套CC0合成样本，每套8页：经营汇报/咨询主题，融资路演/企业主题，数据分析/深色主题。
这些是固定逐页规划的离线编译与真实LibreOffice导出样本，不是联网研究、真实企业数据、真实模型叙事质量验收或商业视觉认证。三个样本共用可核对的数据骨架，不能当作三份已完成的真实商业策划。

每套包含原生可编辑PPTX、实际8页PDF、全页960px JPEG包、联系表、逐页规划、完整来源和单元格绑定/讲稿、文字几何与质量报告、原始请求JSON。manifest.json包含SHA-256。quality-report中的commercialApproval始终false，needs-human-review不是商业通过。

PPTX未嵌入字体。接收端需安装Noto Sans SC（400/700），并人工在PowerPoint/Keynote/WPS核对编辑、字体替换、图表和表格。OFL许可另附。没有任意旧PPT编辑、会话修改或版本对比。

重新生成：corepack pnpm exec tsc -p server/tsconfig.local.json && node scripts/generate-presentation-samples.cjs
真实AI调用需在部署环境配置AI_API_KEY/OPENAI_API_KEY，可选AI_BASE_URL/AI_MODEL，并在技能执行台逐次授权正文处理。
